#############################################################################
# Custom Functions
#
# This is a space to put any custom functions that you want to create; you
# can also re-define functions I wrote, but I generally find it advisable to
# create an function with a different name
